export default {
  // 一、算法函数支持
  // 根据 id 属性获取 top值 和 left值
  function getPosTop(i, j) {
    return j * 120 + 25
  }

  // 二、显示动画

  // 三、主要布局
}
