<template>
  <div class="main_content">日记页面</div>
</template>

<script>
export default {
  data() {
    return {}
  }
}
</script>

<style lang="less" scoped></style>
