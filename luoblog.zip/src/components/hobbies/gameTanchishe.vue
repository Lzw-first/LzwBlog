<template>
  <div class="ganmeBox">
    贪吃蛇游戏界面
  </div>
</template>

<script>
export default {
  data() {
    return {}
  }
}
</script>
