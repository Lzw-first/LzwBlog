<template>
  <div class="ganmeBox">
    吃豆子游戏界面
  </div>
</template>

<script>
export default {
  data() {
    return {}
  }
}
</script>
